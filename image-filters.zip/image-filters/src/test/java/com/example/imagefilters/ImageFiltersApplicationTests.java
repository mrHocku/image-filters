package com.example.imagefilters;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImageFiltersApplicationTests {

    @Test
    void contextLoads() {
    }

}
