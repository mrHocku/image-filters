package com.example.imagefilters;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImageFiltersApplication {

    public static void main(String[] args) {
        SpringApplication.run(ImageFiltersApplication.class, args);
    }

}
