package com.example.imagefilters.services;

import java.awt.*;
import java.awt.image.BufferedImage;

public class ImageFilterService {

    private static final double[][] impulseKernel = new double[][]
            {{0, 0, 0},
             {0, 1, 0},
             {0, 0, 0}};

    private static final double[][] gaussianBlurKernel = new double[][]
            {{0.00000067, 0.00002292, 0.00019117, 0.00038771, 0.00019117, 0.00002292, 0.00000067},
             {0.00002292, 0.00078633, 0.00655965, 0.01330373, 0.00655965, 0.00078633, 0.00002292},
             {0.00019117, 0.00655965, 0.05472157, 0.11098164, 0.05472157, 0.00655965, 0.00019117},
             {0.00038771, 0.01330373, 0.11098164, 0.22508352, 0.11098164, 0.01330373, 0.00038771},
             {0.00019117, 0.00655965, 0.05472157, 0.11098164, 0.05472157, 0.00655965, 0.00019117},
             {0.00002292, 0.00078633, 0.00655965, 0.01330373, 0.00655965, 0.00078633, 0.00002292},
             {0.00000067, 0.00002292, 0.00019117, 0.00038771, 0.00019117, 0.00002292, 0.00000067}};

    private static final ImageUtils imageUtils = new ImageUtils();
    private static final ImageExtender imageExtender = new ImageExtender();
    private static final ConvolutionService convolutionService = new ConvolutionService();


    public BufferedImage getBlurImage(BufferedImage origin) {
        BufferedImage extendedImage = imageExtender.extendByKernel(origin, gaussianBlurKernel);
        Point offset = imageUtils.getOffset(origin, extendedImage);

        int[] pixels = imageUtils.getPixelsFromImage(extendedImage);
        pixels = convolutionService.makeConvolution(pixels, gaussianBlurKernel, offset, extendedImage.getWidth(), extendedImage.getHeight(),  0);
        return imageUtils.convertPixelsToBufferedImage(pixels, extendedImage.getWidth(), extendedImage.getHeight());
    }

    public BufferedImage getBrightnessImage(BufferedImage origin, int level) {
        BufferedImage extendedImage = imageExtender.extendByKernel(origin, impulseKernel);
        Point offset = imageUtils.getOffset(origin, extendedImage);

        int[] pixels = imageUtils.getPixelsFromImage(extendedImage);
        pixels = convolutionService.makeConvolution(pixels, impulseKernel, offset, extendedImage.getWidth(), extendedImage.getHeight(), level);
        return imageUtils.convertPixelsToBufferedImage(pixels, extendedImage.getWidth(), extendedImage.getHeight());
    }

}
