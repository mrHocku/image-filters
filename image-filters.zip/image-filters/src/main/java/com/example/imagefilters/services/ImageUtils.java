package com.example.imagefilters.services;

import java.awt.*;
import java.awt.image.BufferedImage;

public class ImageUtils {

    public BufferedImage convertToRgb(BufferedImage bufferedImage) {
        BufferedImage argbImage = new BufferedImage(bufferedImage.getWidth(), bufferedImage.getHeight(), BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = argbImage.createGraphics();
        g.drawImage(bufferedImage, 0, 0, null);
        g.dispose();
        return argbImage;
    }

    public BufferedImage prepareImage(BufferedImage bufferedImage) {
        return convertToRgb(bufferedImage);
    }

    public BufferedImage convertPixelsToBufferedImage(int[] pixels, int width, int height) {
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        for (int x = 0, y = 0; x < pixels.length; x++) {
            if (x > (y + 1) * width) {
                y++;
            }
            image.setRGB(x % width, y, pixels[x]);
        }
        return image;
    }

    public int[] getPixelsFromImage(BufferedImage image) {
        var pixels = new int[image.getWidth() * image.getHeight()];
        for (int x = 0, y = 0; x < pixels.length; x++) {
            if (x > (y + 1) * image.getWidth()) {
                y++;
            }
            int pixel = image.getRGB(x % image.getWidth(), y);
            pixels[x] = pixel;
        }
        return pixels;
    }

    public BufferedImage drawImage(BufferedImage drawable, BufferedImage image, Point offset) {
        Graphics2D g = drawable.createGraphics();
        g.drawImage(image, offset.x, offset.y, null);
        g.dispose();
        return drawable;
    }

    public Point getOffset(BufferedImage image1, BufferedImage image2) {
        int x = (int) (Math.abs(image1.getWidth() - image2.getWidth()) / 2d);
        int y = (int) (Math.abs(image1.getHeight() - image2.getHeight()) / 2d);
        return new Point(x, y);
    }

}
