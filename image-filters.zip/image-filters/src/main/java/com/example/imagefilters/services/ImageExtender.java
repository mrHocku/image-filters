package com.example.imagefilters.services;

import java.awt.*;
import java.awt.image.BufferedImage;

public class ImageExtender {

    private static final ImageUtils imageUtils = new ImageUtils();

    public BufferedImage extend(BufferedImage image, Point offset) {
        BufferedImage preparedImage = imageUtils.prepareImage(image);
        BufferedImage extendedImage = makeBorder(preparedImage, offset);
        return imageUtils.drawImage(extendedImage, image, offset);
    }

    public BufferedImage extendByKernel(BufferedImage image, double[][] kernel) {
        int halfSize = (int) (kernel.length / 2d);
        Point point = new Point(halfSize, halfSize);
        return this.extend(image, point);
    }

    private BufferedImage makeBorder(BufferedImage image, Point offset) {
        int extendedWidth = offset.x + image.getWidth() + offset.x;
        int extendedHeight = offset.y + image.getHeight() + offset.y;

        int[] extended = new int[extendedWidth * extendedHeight];

        // top left square
        for (int y = 0; y < offset.y; y++) {
            for (int x = 0; x < offset.x; x++) {
                extended[y * extendedWidth + x] = image.getRGB(0, 0);
            }
        }

        // top
        for (int y = 0; y < offset.y; y++) {
            for (int x = offset.x; x < image.getWidth() + offset.x; x++) {
                extended[y * extendedWidth + x] = image.getRGB(x - offset.x, 0);
            }
        }

        // top right square
        for (int y = 0; y < offset.y; y++) {
            for (int x = image.getWidth(); x < extendedWidth; x++) {
                extended[y * extendedWidth + x] = image.getRGB(image.getWidth() - 1, 0);
            }
        }

        // right
        for (int y = offset.y; y < image.getHeight() + offset.y; y++) {
            for (int x = image.getWidth(); x < extendedWidth; x++) {
                extended[y * extendedWidth + x] = image.getRGB(image.getWidth() - 1, y - offset.y);
            }
        }

        // bottom right square
        for (int y = image.getHeight() + offset.y; y < extendedHeight; y++) {
            for (int x = image.getWidth() + offset.x; x < extendedWidth; x++) {
                extended[y * extendedWidth + x] = image.getRGB(image.getWidth() - 1, image.getHeight() - 1);
            }
        }

        // bottom
        for (int y = image.getHeight(); y < extendedHeight; y++) {
            for (int x = offset.x; x < image.getWidth() + offset.x; x++) {
                extended[y * extendedWidth + x] = image.getRGB(x - offset.x, image.getHeight() - 1);
            }
        }

        // bottom left square
        for (int y = image.getHeight() + offset.y; y < extendedHeight; y++) {
            for (int x = 0; x < offset.x; x++) {
                extended[y * extendedWidth + x] = image.getRGB(0, image.getHeight() - 1);
            }
        }

        // left
        for (int y = offset.y; y < image.getHeight() + offset.y; y++) {
            for (int x = 0; x < offset.x; x++) {
                extended[y * extendedWidth + x] = image.getRGB(0, y - offset.y);
            }
        }

        return imageUtils.convertPixelsToBufferedImage(extended, extendedWidth, extendedHeight);
    }

}
