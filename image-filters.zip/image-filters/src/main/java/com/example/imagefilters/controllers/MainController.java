package com.example.imagefilters.controllers;

import com.example.imagefilters.services.ImageFilterService;
import com.example.imagefilters.services.MainService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.awt.image.BufferedImage;

@Controller
public class MainController {

    @Autowired
    private MainService mainService;

    private static final ImageFilterService filterService = new ImageFilterService();

    /**
     * Возвращает единственную страницу.
     * @return шаблон страницы.
     */
    @GetMapping
    public String getIndexPage() {
        return "main";
    }

    /**
     * Получает на вход массив байтов в типе int.
     * Возвращает массив байтов с эффектом "размытие".
     * @param bytes массив байтов исходного изображения.
     * @return массив байтов изображения с применением фильтра "размытие".
     */
    @GetMapping("/blur")
    public ResponseEntity<byte[]> blur(@RequestParam("imageInBytes") int[] bytes) {
        BufferedImage blurImage = mainService.createImageFromBytes(bytes);
        for (int i = 0; i < 9; i++) {
            blurImage = filterService.getBlurImage(blurImage);
        }
        byte[] bytes2 = mainService.getByteArrayFromImage(blurImage);
        return ResponseEntity.ok(bytes2);
    }

    /**
     * Получает на вход массив байтов в типе int.
     * Возвращает массив байтов с эффектом "коррекция яркости".
     * @param bytes массив байтов исходного изображения.
     * @return массив байтов изображения с применением фильтра "коррекция яркости".
     */
    @GetMapping("/brightness")
    public ResponseEntity<byte[]> brightness(@RequestParam("imageInBytes") int[] bytes, @RequestParam("brightnessLevel") Integer brightnessLevel) {
        BufferedImage brightnessImage = mainService.createImageFromBytes(bytes);
        brightnessImage = filterService.getBrightnessImage(brightnessImage, brightnessLevel);
        byte[] bytes2 = mainService.getByteArrayFromImage(brightnessImage);
        return ResponseEntity.ok(bytes2);
    }

}
