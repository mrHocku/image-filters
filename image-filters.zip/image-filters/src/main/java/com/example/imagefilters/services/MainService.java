package com.example.imagefilters.services;

import org.springframework.stereotype.Service;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.stream.IntStream;

@Service
public class MainService {

    /**
     * Получает массив байтов из изображения.
     * @param image изображение.
     * @return массив байтов.
     */
    public byte[] getByteArrayFromImage(BufferedImage image) {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        try {
            ImageIO.write(image, "png", stream);
            return stream.toByteArray();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Получает картинку из массива байтов в типе int (по-другому не регает почему-то).
     * Преобразует массив в массив байтов и на его основе создаёт картинку.
     * @param numbers массив байтов в типе int.
     * @return картинку.
     */
    public BufferedImage createImageFromBytes(int[] numbers) {
        byte[] bytes = fromIntToByteArray(numbers);
        ByteArrayInputStream stream = new ByteArrayInputStream(bytes);
        try {
            return ImageIO.read(stream);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Преобразует массив int в массив byte.
     * @param numbers массив int.
     * @return массив byte.
     */
    private byte[] fromIntToByteArray(int[] numbers) {
        byte[] bytes = new byte[numbers.length];
        IntStream.range(0, bytes.length).forEach(i -> bytes[i] = (byte) numbers[i]);
        return bytes;
    }

}
