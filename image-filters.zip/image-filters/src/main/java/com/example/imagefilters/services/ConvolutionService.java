package com.example.imagefilters.services;

import java.awt.*;
import java.util.Arrays;

public class ConvolutionService {

    public int[] makeConvolution(int[] pixels, double[][] kernel, Point offset, int width, int height, int filterOffset) {
        int kernelSize = kernel.length;
        int halfSize = (int) (kernelSize / 2d);
        int kernelSum = (int) Arrays.stream(kernel).mapToDouble(line -> Arrays.stream(line).sum()).sum();

        int i = 0;
        int[] newPixels = new int[pixels.length];
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                if (x < offset.x || x > width - offset.x || y < offset.y || y > height - offset.y) {
                    newPixels[i++] = pixels[y * width + x];
                    continue;
                }

                double r = 0, g = 0, b = 0;
                for (int sy = 0; sy < kernelSize; sy++) {
                    int yy = Math.min(height - 1, Math.max(offset.y, y + sy - halfSize));
                    for (int sx = 0; sx < kernelSize; sx++) {
                        int xx = Math.min(width - 1, Math.max(offset.x, x + sx - halfSize));
                        int pixel = pixels[yy * width + xx];
                        r += ((pixel >> 16) & 0xff) * kernel[sy][sx];
                        g += ((pixel >> 8) & 0xff) * kernel[sy][sx];
                        b += (pixel & 0xFF) * kernel[sy][sx];
                    }
                }

                r = (int) (Math.min(255, Math.max(0, filterOffset + (r / kernelSum)))) & 0xFF;
                g = (int) (Math.min(255, Math.max(0, filterOffset + (g / kernelSum)))) & 0xFF;
                b = (int) (Math.min(255, Math.max(0, filterOffset + (b / kernelSum)))) & 0xFF;

                newPixels[i++] = ((int) r << 16) | ((int) g << 8) | (int) b;
            }
        }
        return newPixels;
    }

}
